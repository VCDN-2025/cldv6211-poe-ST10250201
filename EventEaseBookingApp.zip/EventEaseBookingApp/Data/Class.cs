﻿namespace EventEaseBookingApp.Data
{
    public class Class
    {
    }
}
