﻿using Microsoft.Extensions.Logging;

namespace EventEaseBookingSystem.Models
{
    public class Venue
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public int Capacity { get; set; }
        public string ImageUrl { get; set; } // Placeholder URL for now

        // Navigation property: one Venue can have many Events
        public ICollection<Event> Events { get; set; }
    }
}
